package com.example.dnd5ecompanion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class StatAssign5eActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stat_assign_5e);

        Intent intent = getIntent();
        String message = intent.getStringExtra(statRoller5E.EXTRA_MESSAGE);

        TextView StatAssignStatList = findViewById(R.id.text_Rolls);
        StatAssignStatList.setText(message);
    }

    public void statProceed(){
        Bundle stats_bundle = new Bundle();
        String temp = "";
        temp = R.id.text_input_str.getText().toString();
        stats_bundle.putFloat("Strength");
        Intent intent = new Intent(this, StatAssign5eActivity.class);
        intent.putExtra("Stats Bundle", stats_bundle);
        startActivity(intent);
    }

    public void statHelp(View view) {
        Snackbar.make(view, "This page lets you assign your stats, the stats you rolled on the previous page are shown on the right. /nThe racial bonuses are also displayed between the two.", Snackbar.LENGTH_INDEFINITE)
                .setAction("Action", null).show();
    }
}
