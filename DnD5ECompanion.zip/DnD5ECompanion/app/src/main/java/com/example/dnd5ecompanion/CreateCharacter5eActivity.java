package com.example.dnd5ecompanion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class CreateCharacter5eActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_character_5e);

        Bundle stats = getIntent().getBundleExtra("Stats Bundle");
        String temp = "";

        temp = stats.getString("Strength");
        TextView stat_show_str = findViewById(R.id.stat_show_str);
        stat_show_str.setText(temp);

        temp = stats.getString("Dexterity");
        TextView stat_show_dex = findViewById(R.id.stat_show_dex);
        stat_show_dex.setText(temp);

        temp = stats.getString("Constitution");
        TextView stat_show_con = findViewById(R.id.stat_show_con);
        stat_show_con.setText(temp);

        temp = stats.getString("Intelligence");
        TextView stat_show_int = findViewById(R.id.stat_show_int);
        stat_show_int.setText(temp);

        temp = stats.getString("Wisdom");
        TextView stat_show_wis = findViewById(R.id.stat_show_wis);
        stat_show_wis.setText(temp);

        temp = stats.getString("Charisma");
        TextView stat_show_cha = findViewById(R.id.stat_show_cha);
        stat_show_cha.setText(temp);
    }
}
